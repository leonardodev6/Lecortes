# Barbearia Lecortes — MVP demonstrativo

Protótipo estático de site institucional, agendamento e painel administrativo, feito com HTML, CSS e JavaScript puro. Os dados são guardados em `localStorage`, sem backend, APIs externas ou sincronização.

## Executar localmente
1. Extraia a pasta `lecortes`.
2. Coloque a logo oficial em `assets/logo.png` (veja observação abaixo).
3. Abra a pasta em VS Code e inicie um servidor local (por exemplo, extensão Live Server). Também pode executar `python -m http.server 8000` na pasta do projeto e abrir `http://localhost:8000`.
4. A página inicial é `index.html`; agendamento em `agendamento.html`; painel em `admin.html`.

## Configurações
- Serviços, preços, produtos, telefone, horários-padrão e senha demonstrativa ficam em `js/config.js`.
- Serviços e funcionamento também podem ser alterados pelo painel, ficando salvos localmente no navegador.
- O número de WhatsApp configurado é `11 95598-6337`.
- Senha inicial do painel: `lecortes2026`. Altere `CONFIG.adminPassword` antes de apresentar, lembrando que é somente uma barreira visual.

## Agendamento
O cliente seleciona serviço, data e horário, informa nome e telefone, revisa os dados e salva a simulação. Os horários ocupados e bloqueios são refletidos no calendário do mesmo navegador. A conversa no WhatsApp é aberta com os dados pré-preenchidos.

## Restaurar demonstração
No painel administrativo, clique em **Restaurar demonstração** e confirme. A ação repõe os agendamentos fictícios, serviços e configurações iniciais.

## Publicar na Vercel
Importe a pasta/repositório como projeto estático na Vercel. Não é necessário build command; use a raiz do projeto como diretório de saída. Os arquivos HTML são acessíveis diretamente.

## Limitações conhecidas
- `localStorage` é específico do navegador e dispositivo; dados não são sincronizados.
- A senha administrativa é demonstrativa, fica exposta no JavaScript e não é autenticação segura.
- Não há backend, banco de dados, notificações, confirmação real pela equipe, nem prevenção de conflito entre dispositivos.
- O WhatsApp apenas abre uma mensagem; não envia automaticamente.
- Horários usam intervalos fixos de 30 minutos. Duração individual por serviço ainda não está modelada.
- A identidade visual utiliza a logo oficial somente quando `assets/logo.png` é fornecida; sem ela, o site mostra um monograma textual.
- A interface usa fonte externa do Google Fonts quando há conexão; fontes de sistema são usadas como fallback.

## Próxima etapa com Supabase
Substituir o módulo `js/storage.js` por uma camada de persistência assíncrona e implementar Supabase Auth, PostgreSQL, políticas RLS e validação transacional de disponibilidade no servidor antes de aceitar reservas reais.
